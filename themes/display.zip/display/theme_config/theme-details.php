<?php

define('THEME_NAME', 'display');
define('THEME_PRETTY_NAME', 'Display');
