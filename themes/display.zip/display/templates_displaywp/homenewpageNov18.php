<?php

/*

Template Name: Home

*/

?>

<?php get_header(); ?>

<style type="text/css">
.the-slider-bullets{
border-bottom: 2px solid #FFBF00;
margin-bottom: 2px !important;
}
</style>

<script type="text/javascript" src="<?php echo get_template_directory_uri().'/js/responsivetab.js' ?>"></script>

<script type="text/javascript">

                jQuery(document).ready(function () {

                    jQuery('#horizontalTab').easyResponsiveTabs({

                        type: 'default', //Types: default, vertical, accordion           

                        width: 'auto', //auto or any width like 600px

                        fit: true   // 100% fit in a container

                    });

                });

               </script>    



<?php if(have_posts()): the_post(); ?>



<?php if(!post_password_required()): ?>



<?php $displaywp_metabox_template_options = displaywp_metabox_template_options_get(get_the_ID()); ?>

<?php if($displaywp_metabox_template_options['home']['rev_slider']['enabled']): ?>

<?php if(function_exists('putRevSlider')): ?>

<?php if(!$displaywp_metabox_template_options['home']['rev_slider']['disable_section']) putRevSlider($displaywp_metabox_template_options['home']['rev_slider']['slug']); ?>

<?php endif; ?>

<?php else: ?>

<?php 



if(!$displaywp_metabox_template_options['home']['main']['disable_section']) echo Tesla_slider::get_slider_html('displaywp_main', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['main'])); ?>

<?php endif; ?>



<?php else: echo get_the_password_form(); endif; ?>
    <?php endif; ?>

<!-- VENKAT STARTED FOUR CIRCLE -->







<!-- END -->    

<!-- =====================================================================

                                 START CONTENT

====================================================================== -->


    



        <?php //if(!post_password_required()): ?>



        <?php //if(!$displaywp_metabox_template_options['home']['services']['disable_section']) echo Tesla_slider::get_slider_html('displaywp_services', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['services'])); ?>

        





        <?php /* venkat need to hide this *///if(!$displaywp_metabox_template_options['home']['team']['disable_section']) echo Tesla_slider::get_slider_html('displaywp_team', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['team'])); ?>

      



























      























        <?php //if(!$displaywp_metabox_template_options['home']['project']['disable_section']) echo displaywp_portfolio($displaywp_metabox_template_options['home']['project']); ?>



        <?php //if(!$displaywp_metabox_template_options['home']['hot_offer']['disable_section']) echo displaywp_hot_offer($displaywp_metabox_template_options['home']['hot_offer']); ?>



        <?php //if(!$displaywp_metabox_template_options['home']['toggle']['disable_section']||!$displaywp_metabox_template_options['home']['recent_posts']['disable_section']): ?>

        

<div class="wholbg container">
<div class="bg-lf-shadow"></div>


        <!-- welcome content-->
        <div class="homecirclereadmore">
         <div class="row ">

            <div class="col-md-8 welcomebox">

            <h4>Welcome to Jet Relcations</h4>

            <p>At Jet relocations packing and moving company, we offer varieties in House hold packing and material moving services. We supply high quality packing boxes used during moving and covering material used to protect the furniture, Tape and bubble wrap used to fragile items, If needed we also offer custom wood crating for breakable items such as glassware, showcase items. </p>

<p>Relying on the service you want, home holds shifting may take a couple of hours or a couple of day.  As Your local Packer and Mover Company we take care of every aspect of your shifting, so there is no need to worry, we have the knowledge, experience and care to execute the move to your new surrounds smoothly and efficiently.Relying on the service you want, home holds shifting may take a couple of hours or a couple of day.  As Your local Packer and Mover Company we take care of every aspect of your shifting, so there is no need to worry, we have the knowledge, experience and care to execute the move to your new surrounds smoothly and efficiently.</p>
<p>Everything they say about House hold shifting is stress full, is a time consuming, it takes lot of effort  and we might also call it quite a headache! But we are here to prove that it can be totally the other way around.Everything they say about House hold shifting is stress full, is a time consuming, it takes lot of effort  and we might also call it quite a headache! But we are here to prove that it can be totally the other way around.  </p>
<p>Everything they say about House hold shifting is stress full, is a time consuming, it takes lot of effort  and we might also call it quite a headache! But we are here to prove that it can be totally the other way around.Everything they say about House hold shifting is stress full, is a time consuming, it takes lot of effort  and we might also call it quite a headache! But we are here to prove that it can be totally the other way around. </p>
            </div>
            <div class="col-md-4 quick-enquiry">



              <h4> Send Enquiry</h4>

              <div class="formbox">

                <?php echo do_shortcode('[contact-form-7 id="380" title="homecontact"]') ?>

            </div>

            </div>

         </div>

<!---  end -->  




<div class="row our-works content_top">

                <div class="col-md-3 flag_grid wow slideInLeft" style="visibility: visible; animation-name: slideInLeft;">

                 <div class="work-member-cover">

                      <img src="http://jetrelocations.com/wp-content/themes/display/images/officeshifting.jpg" alt="team member">

                 </div>

                 <div class="flag_desc">

                    <h3><a href="#">Office shifting</a></h3>

                    <p>aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis</p>

                    <a href="<?php echo get_the_permalink();  ?>office-shifting-and-corporate-shifting/" class="link">Read More</a>

                 </div>

                 <div class="clearfix"> </div>

                </div>

                <div class="col-md-3 flag_grid wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">

                 <div class="work-member-cover">
                    
                    <img src="http://jetrelocations.com/wp-content/themes/display/images/homeshifting.jpg" alt="team member">

                 </div>

                 <div class="flag_desc">

                    <h3><a href="#">Home shifting</a></h3>

                    <p>aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis</p>

                    <a href="<?php echo get_the_permalink();  ?>house-hold-goods-shifting/" class="link">Read More</a>

                 </div>

                  <div class="clearfix"> </div>

                </div>

                <div class="col-md-3 wow slideInRight" style="visibility: visible; animation-name: slideInRight;">

                <div class="work-member-cover">

                 <img src="http://jetrelocations.com/wp-content/themes/display/images/cartran.jpg" alt="team member">

                 </div>

                 <div class="flag_desc">

                    <h3><a href="#">Storage & Ware Housing</a></h3>

                    <p>aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis</p>

                    <a href="<?php echo get_the_permalink();  ?>warehousing-and-storage/" class="link">Read More</a>

                 </div>

                  <div class="clearfix"> </div>

                </div>

                <div class="col-md-3 wow slideInRight" style="visibility: visible; animation-name: slideInRight;">

                 <div class="work-member-cover">

                 <img src="http://jetrelocations.com/wp-content/themes/display/images/machinaryshifting.jpg" alt="team member">

                 </div>

                 <div class="flag_desc">

                    <h3><a href="#">Car/Bike transportation</a></h3>

                    <p>aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis</p>

                    <a href="<?php echo get_the_permalink();  ?>car-transportation/" class="link">Read More</a>

                 </div>

                  <div class="clearfix"> </div>

                </div>

            </div>






        <div class="row">

            

            <?php 

            //if(!$displaywp_metabox_template_options['home']['toggle']['disable_section']): ?>

            <!--<div class="<?php //echo !$displaywp_metabox_template_options['home']['recent_posts']['disable_section']?'span6':'span12'; ?>">

                <?php //echo Tesla_slider::get_slider_html('displaywp_toggle', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['toggle'], 'category' => $displaywp_metabox_template_options['home']['toggle']['category'])); ?>

            </div> -->





            <div class="col-md-4 wow bounceInRight" style="padding-left: 0px;visibility: visible; animation-name: bounceInRight; margin:0px;padding:0px;">

   

                <div class="sap_tabs">  



                         <div id="horizontalTab" style="display: block; width: 100%; margin: 0px;">

                          <ul class="resp-tabs-list">

                              <li class="resp-tab-item resp-tab-active" aria-controls="tab_item-0" role="tab"><span>Mission</span></li>

                              <li class="resp-tab-item" aria-controls="tab_item-1" role="tab"><span>Safety Policy</span></li>

                              <li class="resp-tab-item" aria-controls="tab_item-2" role="tab"><span>Quality Policy</span></li>

                              <div class="clear"></div>

                          </ul>                  

                            <div class="resp-tabs-container">

                                <h2 class="resp-accordion resp-tab-active" role="tab" aria-controls="tab_item-0"><span class="resp-arrow"></span>Mission</h2><div class="tab-1 resp-tab-content resp-tab-content-active" aria-labelledby="tab_item-0" style="display:block">

                                    <div class="facts">

                                      <div class="tab_box">

                                        

                                        <p>"To be a globally recognized corporation that provides best Household Transportation &amp; logistics solutions, delivered by best-in-class people through fairness, business ethics, global reach and technological expertise; building long term relationships with all our associates, customers, partners, and employees"</p>

                                       </div>

                                               

                                    </div>

                                 </div> 

                                  <h2 class="resp-accordion" role="tab" aria-controls="tab_item-1"><span class="resp-arrow"></span>Safety Policy</h2><div class="tab-1 resp-tab-content" aria-labelledby="tab_item-1">

                                    <div class="facts">

                                      <div class="tab_box">

                                       

                                        <ul class="tab_list">

                                        <li><a href="#">Zero motor accidents</a></li>

                                        <li><a href="#">Zero damage / breakage</a></li>

                                        <li><a href="#">Zero fatalities</a></li>

                                        <li><a href="#">Zero injuries</a></li>

                                        <li><a href="#">Zero unsafe acts</a></li>

                                        <li><a href="#">Zero net emissions</a></li>

                                      </ul>  

                                       </div>

                                                

                                    </div>

                                 </div> 

                                  <h2 class="resp-accordion" role="tab" aria-controls="tab_item-2"><span class="resp-arrow"></span>Quality Policy</h2><div class="tab-1 resp-tab-content" aria-labelledby="tab_item-2">

                                    <div class="facts">

                                      <div class="tab_box">

                                        

                                        <p>Jet relocations' quality policy is : To achieve sustained, profitable growth by providing services which consistently satisfy the needs and expectations of its customers. Tamper proof sealing and locking - highest quality work. To improve efficiency of our Human Resources. </p>

                                       </div>

                                                 

                                    </div>

                                 </div>                                  

                              </div>    

                            </div>

                      </div>

            </div> 

            

            <div class="col-md-8" style="padding-right: 0px;
margin: 0px;">

            <!-- testimonial start -->



            <div id="tcb-testimonial-carousel" class="carousel slide" data-ride="carousel">

              <!-- Indicators -->

            <ol class="carousel-indicators">

                <li data-target="#tcb-testimonial-carousel" data-slide-to="0" class="active"></li>

                <li data-target="#tcb-testimonial-carousel" data-slide-to="1"></li>

               <!--  <li data-target="#tcb-testimonial-carousel" data-slide-to="2"></li> -->

            </ol>

             <!-- Wrapper for slides -->

            <div class="carousel-inner">

                <div class="item active">

                    <div class="row">

                        <div class="col-xs-12" style="padding-top:15px">

                           <figure class="clearfix">

                               <div class="col-md-2 col-sm-2 col-xs-12"><img class="img-responsive media-object" src="http://jetrelocations.com/wp-content/themes/display/images/ajay.JPG"> </div>

                               <div class="col-md-10 col-sm-10 col-xs-12">

                                    <figcaption class="caption">

                                        <p class="text-brand lead no-margin">Ajay P.V. </p>

                                        <p><span class="glyphicon glyphicon-thumbs-up"></span>
                                        "Honest.Fast.Safe. I chose Jet relocations to shift from Koramangala To Bellandur and it was a pleasurable experience. I did not touch a thing! My entire house was inside carton boxes within no time and was relocated to my new house in a very safe manner. Brilliant job!"
                                         </p>

                                        <blockquote class="no-margin">

                                            <p>Ajay P.V.</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> Software Engineer, Bangalore</cite></small> </blockquote>

                                    </figcaption>

                               </div>

                           </figure>

                        </div>

                    </div>

                </div>

                <div class="item">

                    <div class="row">

                        <div class="col-xs-12" style="padding-top:15px">

                           <figure class="clearfix">

                               <div class="col-md-2 col-sm-2 col-xs-12"><img class="img-responsive media-object" src="http://jetrelocations.com/wp-content/themes/display/images/avt.jpg" style="border-radius: 1000px;"> </div>

                               <div class="col-md-10 col-sm-10 col-xs-12">

                                    <figcaption class="caption">

                                        <p class="text-brand lead no-margin">Mr. Ramanujam</p>

                                        <p><span class="glyphicon glyphicon-thumbs-up"></span> "We wanted to quickly move to a new office and timelines were very short. We called in Jet Relocations and from initial survey to complete relocation, it was done professionally and smoothly”.</p>

                                        <blockquote class="no-margin">

                                            <p>Mr. Ramanujam</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> Samsung, Bangalore</cite></small> </blockquote>

                                    </figcaption>

                               </div>

                           </figure>

                        </div>

                    </div>

                </div>

<!--                 <div class="item">

                    <div class="row">

                        <div class="col-xs-12" style="padding-top:15px">

                           <figure class="clearfix">

                               <div class="col-md-2 col-sm-2 col-xs-12"><img class="img-responsive media-object" src="https://s3.amazonaws.com/uifaces/faces/twitter/brad_frost/128.jpg"> </div>

                               <div class="col-md-10 col-sm-10 col-xs-12">

                                    <figcaption class="caption">

                                        <p class="text-brand lead no-margin">I can't wait to test this out.</p>

                                        <p><span class="glyphicon glyphicon-thumbs-up"></span> To be a globally recognized corporation that provides best Household Transportation & logistics solutions, delivered by best-in-class people through fairness, business ethics, global reach and technological expertise; building long term relationships with all our associates, customers, partners, and employees .</p>

                                        <blockquote class="no-margin">

                                            <p>Someone Famous</p> <small><cite title="Source Title"><i class="glyphicon glyphicon-globe"></i> www.example1.com</cite></small> </blockquote>

                                    </figcaption>

                               </div>

                           </figure>
                        </div>

                    </div>

                </div> -->

            </div>

            <a class="left carousel-control" href="#tcb-testimonial-carousel" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span> </a>

            <a class="right carousel-control" href="#tcb-testimonial-carousel" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span> </a>

        </div>

</div>

            <!-- end -->

            <?php 

            ///endif;

             ?>

            

            <?php //if(!$displaywp_metabox_template_options['home']['recent_posts']['disable_section']): ?>

            <!--

            <div class="<?php echo !$displaywp_metabox_template_options['home']['toggle']['disable_section']?'span5 offset1':'span12'; ?>">

                <?php //echo displaywp_posts_latest($displaywp_metabox_template_options['home']['recent_posts']); ?>

            </div>

        -->

            <?php //endif; ?>

        </div>

        



        <?php //if(!$displaywp_metabox_template_options['home']['testimonials']['disable_section']) echo Tesla_slider::get_slider_html('displaywp_tstmnls', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['testimonials'])); ?>

        

        <?php //if(!$displaywp_metabox_template_options['home']['clients']['disable_section']) echo Tesla_slider::get_slider_html('displaywp_clients', array('shortcode_parameters' => $displaywp_metabox_template_options['home']['clients'])); ?>

 

        <?php //if(!$displaywp_metabox_template_options['home']['contact']['disable_section']) echo displaywp_contact($displaywp_metabox_template_options['home']['contact']); ?>



        <?php //the_content(); ?>



        <?php //else: //echo get_the_password_form();

         //endif; ?>

        

    </div>
<!-- here welcome content starts -->


 <div class="bg-rg-shadow"></div>
</div>






    





    <!-- end -->

                   

</div>

<!-- =====================================================================

                                 END CONTENT

====================================================================== -->

<?php //endif; ?>

<?php get_footer(); ?>